<?php
// Heading
$_['heading_title'] = 'Log de Errores';

// Text
$_['text_success']  = 'Éxito: Has limpiado el log de errores satisfactoriamente!';
?>