<?php
$_['lang_openbay']              = 'OpenBay Pro';
$_['lang_page_title']           = 'OpenBay Pro para eBay';
$_['lang_ebay']                 = 'eBay';
$_['lang_heading']              = 'Complementos';
$_['lang_addon_desc']           = 'Complementos son modulos que son conocidos  por soportar o mejorar la usabilidad de OpenBay Pro.';
$_['lang_addon_name']           = 'Nombre del complemento';
$_['lang_addon_version']        = 'Versión';
$_['lang_addon_none']           = 'No tienes complementos instalados';
$_['lang_error_validation']     = 'Usted necesita registrar su API token y habilitar el modulo.';
$_['lang_btn_return']           = 'Regresar';

