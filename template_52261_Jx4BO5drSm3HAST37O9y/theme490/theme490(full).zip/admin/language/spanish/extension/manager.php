<?php
// Heading
$_['heading_title']    = 'Extensión Gerente';

// Text
$_['text_success']     = 'Exitó: Has instalado tu extensión!';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar la extensión de gerentes!';
$_['error_upload']     = 'Se require subir archivo!';
$_['error_filetype']   = 'Tipo de Archivo Invalido!';
?>
