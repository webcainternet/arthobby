<?php
// Heading
$_['heading_title']    = 'Feed de productos';

// Text
$_['text_install']     = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']      = 'Nombre del feed del producto';
$_['column_status']    = 'Estatus';
$_['column_action']    = 'Acción';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar los feeds!';
?>
