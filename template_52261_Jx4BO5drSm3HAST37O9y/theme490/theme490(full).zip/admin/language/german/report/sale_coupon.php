<?php
// Heading
$_['heading_title']    = 'Bericht Aktionsgutschein';

// Column
$_['column_name']      = 'Bezeichnung';
$_['column_code']      = 'Code';
$_['column_orders']    = 'Aufträge';
$_['column_total']     = 'Summe';
$_['column_action']    = 'Aktion';

// Entry
$_['entry_date_start'] = 'Startdatum:';
$_['entry_date_end']   = 'Ablaufdatum:';
?>