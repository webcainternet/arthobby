<?php
// Heading
$_['heading_title']       = 'Deutsche Sprache';

// Text
$_['text_success']        = 'Erfolgreich: Modul Deutsche Sprache geändert!';
$_['text_module']         = 'Modul';

// Error
$_['error_permission']    = 'Warnung: Sie haben keine Berechtigung, um das Modul Deutsche Sprache zu ändern!';
?>