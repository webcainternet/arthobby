<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Produktfeeds';
$_['text_success']     = 'Erfolgreich: Google Sitemap Feed aktualisiert!';

// Entry
$_['entry_status']     = 'Status:';
$_['entry_data_feed']  = 'URL Datenfeed:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um Google Sitemap zu ändern!';
?>