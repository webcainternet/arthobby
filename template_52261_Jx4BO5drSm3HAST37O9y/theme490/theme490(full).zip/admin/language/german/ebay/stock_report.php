<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro für eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Lagerbestandsbericht';
$_['lang_btn_return']                   = 'Zurück';
$_['lang_report_label']                 = 'E-Mail Bericht';
$_['lang_report_btn']                   = 'Anfrage';
$_['lang_ajax_load_error']              = 'Es konnte keine Verbindung hergestellt werden.';
$_['lang_ajax_load_sent']               = 'Anfrage wurde gesendet';
?>