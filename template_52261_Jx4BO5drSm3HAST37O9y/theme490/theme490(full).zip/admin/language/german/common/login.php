<?php
// Heading
$_['heading_title']      = 'Verwaltung';

// Text
$_['text_heading']       = 'Verwaltung';
$_['text_login']         = 'Bitte Anmeldedetails eingeben.';
$_['text_forgotten']     = 'Passwort vergessen';

// Entry
$_['entry_username']     = 'Benutzername:';
$_['entry_password']     = 'Passwort:';

// Button
$_['button_login']       = 'Anmelden';

// Error
$_['error_login']        = 'Keine Übereinstimmung mit Benutzername und/oder Passwort.';
$_['error_token']        = 'Die Sitzung ist ungültig oder abgelaufen. Bitte melden Sie sich neu an.';
?>