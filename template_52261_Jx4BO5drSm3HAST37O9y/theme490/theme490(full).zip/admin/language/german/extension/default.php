<?php
$_['lang_openbay_new']              = 'Neues Angebot hinzufügen';
$_['lang_openbay_edit']             = 'Angebote anzeigen/ändern';
$_['lang_openbay_fix']              = 'Problem lösen';
$_['lang_openbay_processing']       = 'In Bearbeitung';

$_['lang_amazonus_saved']           = 'Gespeichert (nicht hochgeladen)';
$_['lang_amazon_saved']             = 'Gespeichert (nicht hochgeladen)';
$_['lang_play_pending_new']         = 'Ausstehend (neu)';
$_['lang_play_pending_updated']     = 'Ausstehend (aktualisiert)';
$_['lang_play_warning']             = 'Warnungen';
$_['lang_play_pending_delete']      = 'Ausstehend (löschen)';
$_['lang_play_stock_updating']      = 'Lagerbestand aktualisieren';

$_['lang_markets']                  = 'Märkte';
$_['lang_bulk_btn']                 = 'eBay Massenupload';

$_['lang_marketplace']              = 'Marktplatz';
$_['lang_status']                   = 'Status';
$_['lang_option']                   = 'Option';
?>