<?php
// Heading
$_['heading_title'] = 'Protokolldatei';

// Text
$_['text_success']  = 'Erfolgreich: Protokolldatei für Fehler gelöscht!';
?>